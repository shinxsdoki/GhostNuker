import discord
from discord.ext import commands
import asyncio
import os
import sys
from colorama import Fore, Style, init
import random
import time
import threading

# Inicjalizacja colorama
init(autoreset=True)

def clear_console():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_gradient_text(text):
    """Drukuje tekst z szaro-białym gradientem"""
    colors = [Fore.LIGHTBLACK_EX, Fore.WHITE, Fore.LIGHTWHITE_EX]
    result = ""
    for i, char in enumerate(text):
        color_index = i % len(colors)
        result += colors[color_index] + char
    return result + Style.RESET_ALL

def print_nuker_art():
    """Drukuje ASCII art NUKER z gradientem"""
    nuker_art = r"""
  /$$$$$$  /$$                             /$$     /$$   /$$           /$$                                      
 /$$__  $$| $$                            | $$    | $$$ | $$          | $$                                      
| $$  \__/| $$$$$$$   /$$$$$$   /$$$$$$$ /$$$$$$  | $$$$| $$ /$$   /$$| $$   /$$  /$$$$$$   /$$$$$$             
| $$ /$$$$| $$__  $$ /$$__  $$ /$$_____/|_  $$_/  | $$ $$ $$| $$  | $$| $$  /$$/ /$$__  $$ /$$__  $$            
| $$|_  $$| $$  \ $$| $$  \ $$|  $$$$$$   | $$    | $$  $$$$| $$  | $$| $$$$$$/ | $$$$$$$$| $$  \__/            
| $$  \ $$| $$  | $$| $$  | $$ \____  $$  | $$ /$$| $$\  $$$| $$  | $$| $$_  $$ | $$_____/| $$                  
|  $$$$$$/| $$  | $$|  $$$$$$/ /$$$$$$$/  | $$$$/| $$ \  $$|  $$$$$$/| $$ \  $$|  $$$$$$$| $$                  
 \______/ |__/  |__/ \______/ |_______/    \___/  |__/  \__/ \______/ |__/  \__/ \_______/|__/                 
"""
    lines = nuker_art.strip().split('\n')
    for line in lines:
        print(print_gradient_text(line))

def print_banner():
    """Wyświetla banner"""
    clear_console()
    print("\n" + "="*80)
    print_nuker_art()
    print("="*80)
    print(f"{Style.BRIGHT}{print_gradient_text('TURBO DISCORD NUKER ULTRA - SUPER FAST')}")
    print(f"{print_gradient_text('ULTRA SZYBKI - MAX WYDAJNOŚĆ - ANTY RATELIMIT')}")
    print("="*80)

# Tłumaczenia
TRANSLATIONS = {
    'pl': {
        'login_title': 'WPROWADŹ DANE LOGOWANIA',
        'token': 'Token bota: ',
        'server_id': 'ID serwera: ',
        'invalid_id': 'Nieprawidłowe ID!',
        'menu_title': 'MENU GŁÓWNE - TURBO MODE',
        'options': [
            "[1] TURBO-NUKER ULTRA (MAX SPEED)",
            "[2] SPAMER KANAŁÓW TEKST. TURBO",
            "[3] SPAMER KANAŁÓW GŁOS. TURBO", 
            "[4] SPAMER RÓL TURBO",
            "[5] SPAMER WIADOMOŚCI TURBO",
            "[6] ZMIEŃ JĘZYK",
            "[7] WYJŚCIE"
        ],
        'choose': 'Wybierz opcję: ',
        'invalid': 'Zły wybór!',
        'connected': 'Bot zalogowany jako {}',
        'nuker_warn': '⚠️ ULTRA SZYBKIE USUWANIE WSZYSTKIEGO! ⚠️',
        'confirm': 'Potwierdź (t/n): ',
        'role_name': 'Nazwa ról: ',
        'text_name': 'Nazwa kanałów tekst.: ',
        'voice_name': 'Nazwa kanałów głos.: ',
        'message_content': 'Treść wiadomości: ',
        'message_count': 'Liczba wiadomości na kanał: ',
        'deleting': '⚡ Usuwam kanały TURBO SPEED...',
        'creating': '⚡ Tworzę nowe TURBO SPEED...',
        'created': 'Utworzono: {}',
        'deleted': 'Usunięto: {}',
        'error': 'Błąd: {}',
        'count': 'Ile utworzyć? (MAX: ',
        'goodbye': 'Do zobaczenia!',
        'waiting_bot': 'Oczekiwanie na połączenie bota...',
        'bot_timeout': 'Bot nie połączył się! Sprawdź token.',
        'press_enter': 'Naciśnij Enter...',
        'spamming_messages': '⚡ Wysyłanie wiadomości TURBO...',
        'message_sent': 'Wysłano wiadomość: {}',
        'max_limit': 'Maksymalny limit: {}',
        'spam_loop': '♾️  SPAM W TRYBIE NIESKOŃCZONEJ PĘTLI ♾️',
        'loop_count': 'Ile razy powtórzyć spam? (0 = nieskończoność): ',
        'delay': 'Opóźnienie między akcjami (sekundy): ',
        'current_loop': 'Pętla: {}'
    },
    'en': {
        'login_title': 'ENTER LOGIN DETAILS',
        'token': 'Bot token: ',
        'server_id': 'Server ID: ',
        'invalid_id': 'Invalid ID!',
        'menu_title': 'MAIN MENU - TURBO MODE',
        'options': [
            "[1] TURBO-NUKER ULTRA (MAX SPEED)",
            "[2] TEXT CHANNEL SPAMMER TURBO", 
            "[3] VOICE CHANNEL SPAMMER TURBO",
            "[4] ROLE SPAMMER TURBO",
            "[5] MESSAGE SPAMMER TURBO",
            "[6] CHANGE LANGUAGE",
            "[7] EXIT"
        ],
        'choose': 'Choose option: ',
        'invalid': 'Invalid choice!',
        'connected': 'Bot logged in as {}',
        'nuker_warn': '⚠️ ULTRA FAST DELETING EVERYTHING! ⚠️',
        'confirm': 'Confirm (y/n): ',
        'role_name': 'Role name: ',
        'text_name': 'Text channels name: ',
        'voice_name': 'Voice channels name: ',
        'message_content': 'Message content: ',
        'message_count': 'Number of messages per channel: ',
        'deleting': '⚡ Deleting channels TURBO SPEED...',
        'creating': '⚡ Creating new TURBO SPEED...',
        'created': 'Created: {}',
        'deleted': 'Deleted: {}',
        'error': 'Error: {}',
        'count': 'How many to create? (MAX: ',
        'goodbye': 'Goodbye!',
        'waiting_bot': 'Waiting for bot connection...',
        'bot_timeout': 'Bot failed to connect! Check token.',
        'press_enter': 'Press Enter...',
        'spamming_messages': '⚡ Spamming messages TURBO...',
        'message_sent': 'Message sent: {}',
        'max_limit': 'Maximum limit: {}',
        'spam_loop': '♾️  SPAM IN INFINITE LOOP MODE ♾️',
        'loop_count': 'How many times to repeat spam? (0 = infinity): ',
        'delay': 'Delay between actions (seconds): ',
        'current_loop': 'Loop: {}'
    }
}

class DiscordManager:
    def __init__(self):
        self.token = None
        self.guild_id = None
        self.bot = None
        self.bot_ready = False
        self.running = True
        self.language = 'pl'
        self.bot_thread = None
        self.bot_loop = None

    def t(self, key, *args):
        """Pobiera tłumaczenie"""
        translation = TRANSLATIONS[self.language].get(key, key)
        if args:
            return translation.format(*args)
        return translation

    def start_bot_in_thread(self):
        """Uruchamia bota w osobnym wątku z własną pętlą asyncio"""
        self.bot_loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.bot_loop)
        
        # Poprawione intencje
        intents = discord.Intents.all()
        intents.members = True
        intents.guilds = True
        intents.messages = True
        intents.message_content = True
        
        self.bot = commands.Bot(command_prefix='!', intents=intents, loop=self.bot_loop)
        
        @self.bot.event
        async def on_ready():
            print(f"{Fore.GREEN}{self.t('connected', self.bot.user)}")
            self.bot_ready = True
        
        try:
            self.bot_loop.run_until_complete(self.bot.start(self.token))
        except discord.LoginFailure:
            print(f"{Fore.RED}❌ Nieprawidłowy token bota!")
            self.running = False
        except Exception as e:
            print(f"{Fore.RED}❌ Błąd: {e}")
            self.running = False
        finally:
            if not self.bot_loop.is_closed():
                self.bot_loop.close()

    async def ensure_bot_ready(self):
        """Czeka aż bot będzie gotowy"""
        if self.bot_ready:
            return True
            
        print(f"{Fore.YELLOW}{self.t('waiting_bot')}")
        
        start_time = time.time()
        while time.time() - start_time < 30:
            if self.bot_ready:
                return True
            await asyncio.sleep(0.5)
        
        print(f"{Fore.RED}{self.t('bot_timeout')}")
        return False

    def get_credentials(self):
        """Pobiera dane logowania"""
        print(f"\n{Fore.WHITE}{self.t('login_title')}")
        print(f"{Fore.LIGHTBLACK_EX}{'='*40}")
        self.token = input(f"{Fore.WHITE}{self.t('token')}").strip()
        try:
            self.guild_id = int(input(f"{Fore.WHITE}{self.t('server_id')}").strip())
        except ValueError:
            print(f"{Fore.RED}{self.t('invalid_id')}")
            sys.exit(1)
        print(f"{Fore.LIGHTBLACK_EX}{'='*40}")

    def print_horizontal_menu(self):
        """Wyświetla poziome menu"""
        print(f"\n{Fore.WHITE}{self.t('menu_title')}")
        print(f"{Fore.LIGHTBLACK_EX}{'='*60}")
        
        options = self.t('options')
        line1 = "  ".join(options[:4])
        line2 = "  ".join(options[4:])
        print(f"{Fore.LIGHTWHITE_EX}{line1}")
        print(f"{Fore.LIGHTWHITE_EX}{line2}")
        
        print(f"{Fore.LIGHTBLACK_EX}{'='*60}")

    async def change_language(self):
        """Zmienia język"""
        print(f"\n{Fore.WHITE}Wybierz język / Choose language:")
        print(f"{Fore.LIGHTWHITE_EX}[1] Polski")
        print(f"{Fore.LIGHTWHITE_EX}[2] English")
        
        choice = input(f"{Fore.WHITE}Wybierz (1-2): ").strip()
        if choice == '1':
            self.language = 'pl'
            print(f"{Fore.GREEN}✅ Język ustawiony na Polski")
        elif choice == '2':
            self.language = 'en'
            print(f"{Fore.GREEN}✅ Language set to English")
        else:
            print(f"{Fore.RED}❌ Zły wybór!")
        
        input(f"{Fore.WHITE}{self.t('press_enter')}")

    async def main_menu(self):
        """Główne menu aplikacji"""
        while self.running:
            clear_console()
            print_banner()
            self.print_horizontal_menu()
            
            choice = input(f"\n{Fore.WHITE}{self.t('choose')}").strip()
            
            if choice == '1': 
                await self.turbo_nuker_ultra()
            elif choice == '2': 
                await self.channel_spammer_turbo("text")
            elif choice == '3': 
                await self.channel_spammer_turbo("voice")
            elif choice == '4': 
                await self.role_spammer_turbo()
            elif choice == '5': 
                await self.message_spammer_turbo()
            elif choice == '6': 
                await self.change_language()
            elif choice == '7': 
                print(f"{Fore.GREEN}{self.t('goodbye')}")
                self.running = False
                break
            else:
                print(f"{Fore.RED}{self.t('invalid')}")
                input(f"{Fore.WHITE}{self.t('press_enter')}")

    async def get_guild(self):
        """Pobiera serwer Discord"""
        if not await self.ensure_bot_ready():
            return None
            
        try:
            guild = self.bot.get_guild(self.guild_id)
            if guild:
                return guild
            else:
                print(f"{Fore.RED}❌ Nie można znaleźć serwera!")
                return None
        except Exception as e:
            print(f"{Fore.RED}{self.t('error', e)}")
            return None

    async def turbo_nuker_ultra(self):
        """Turbo nuker ULTRA - maksymalna prędkość"""
        guild = await self.get_guild()
        if not guild: 
            return
        
        print(f"{Fore.RED}⚡ {self.t('nuker_warn')} ⚡")
        confirmation = input(f"{Fore.WHITE}{self.t('confirm')}").lower()
        
        if confirmation not in ['t', 'tak', 'y', 'yes']:
            return
        
        # Pobierz ustawienia pętli
        try:
            loop_count = int(input(f"{Fore.WHITE}{self.t('loop_count')}")) or 1
        except:
            loop_count = 1
            
        try:
            delay = float(input(f"{Fore.WHITE}{self.t('delay')}")) or 0.5
        except:
            delay = 0.5
        
        role_name = input(f"{Fore.WHITE}{self.t('role_name')}").strip() or "NUKED"
        text_name = input(f"{Fore.WHITE}{self.t('text_name')}").strip() or "nuked"
        voice_name = input(f"{Fore.WHITE}{self.t('voice_name')}").strip() or "nuked"
        
        current_loop = 0
        infinite = loop_count == 0
        
        while infinite or current_loop < loop_count:
            current_loop += 1
            print(f"{Fore.CYAN}♾️ {self.t('current_loop', current_loop)}")
            
            # 1. USUWANIE - MASOWE
            print(f"{Fore.RED}⚡ {self.t('deleting')}")
            
            # Usuwanie kanałów - MASOWO z mniejszymi opóźnieniami
            delete_tasks = []
            for channel in list(guild.channels):
                delete_tasks.append(channel.delete())
            
            # Wykonaj wszystkie zadania usuwania naraz
            results = await asyncio.gather(*delete_tasks, return_exceptions=True)
            for i, result in enumerate(results):
                if not isinstance(result, Exception):
                    print(f"{Fore.RED}⚡ {self.t('deleted', f'Kanał {i+1}')}")
            
            # Usuwanie ról - MASOWO
            delete_role_tasks = []
            for role in [role for role in guild.roles if not role.managed and role != guild.default_role]:
                delete_role_tasks.append(role.delete())
            
            results = await asyncio.gather(*delete_role_tasks, return_exceptions=True)
            for i, result in enumerate(results):
                if not isinstance(result, Exception):
                    print(f"{Fore.RED}⚡ {self.t('deleted', f'Rola {i+1}')}")
            
            # 2. TWORZENIE - MASOWE
            print(f"{Fore.GREEN}⚡ {self.t('creating')}")
            
            # Kanały tekstowe (50 - MAX)
            create_text_tasks = []
            for i in range(50):
                create_text_tasks.append(guild.create_text_channel(f"{text_name}-{i+1}"))
            
            results = await asyncio.gather(*create_text_tasks, return_exceptions=True)
            for i, result in enumerate(results):
                if not isinstance(result, Exception):
                    print(f"{Fore.GREEN}⚡ {self.t('created', f'{text_name}-{i+1}')}")
            
            # Kanały głosowe (50 - MAX)
            create_voice_tasks = []
            for i in range(50):
                create_voice_tasks.append(guild.create_voice_channel(f"{voice_name}-{i+1}"))
            
            results = await asyncio.gather(*create_voice_tasks, return_exceptions=True)
            for i, result in enumerate(results):
                if not isinstance(result, Exception):
                    print(f"{Fore.GREEN}⚡ {self.t('created', f'{voice_name}-{i+1}')}")
            
            # Role (20 - MAX)
            create_role_tasks = []
            for i in range(20):
                create_role_tasks.append(guild.create_role(name=f"{role_name}-{i+1}", color=discord.Color.random()))
            
            results = await asyncio.gather(*create_role_tasks, return_exceptions=True)
            for i, result in enumerate(results):
                if not isinstance(result, Exception):
                    print(f"{Fore.GREEN}⚡ {self.t('created', f'{role_name}-{i+1}')}")
            
            if not infinite:
                print(f"{Fore.GREEN}✅⚡ TURBO NUKER ULTRA ZAKOŃCZONY! ⚡")
                break
                
            # Dodaj opóźnienie między pętlami
            await asyncio.sleep(delay)
        
        input(f"{Fore.WHITE}{self.t('press_enter')}")

    async def channel_spammer_turbo(self, channel_type):
        """Spamer kanałów TURBO"""
        guild = await self.get_guild()
        if not guild: 
            return
        
        name = input(f"{Fore.WHITE}{self.t('text_name' if channel_type == 'text' else 'voice_name')}").strip()
        if not name:
            name = "spam" if channel_type == "text" else "spam"
        
        # Pobierz ustawienia pętli
        try:
            loop_count = int(input(f"{Fore.WHITE}{self.t('loop_count')}")) or 1
        except:
            loop_count = 1
            
        try:
            delay = float(input(f"{Fore.WHITE}{self.t('delay')}")) or 0.5
        except:
            delay = 0.5
        
        max_limit = 50
        try:
            count = min(int(input(f"{Fore.WHITE}{self.t('count')}{max_limit}): ")) or 30, max_limit)
        except:
            count = 30
        
        current_loop = 0
        infinite = loop_count == 0
        
        while infinite or current_loop < loop_count:
            current_loop += 1
            print(f"{Fore.CYAN}♾️ {self.t('current_loop', current_loop)}")
            
            create_tasks = []
            for i in range(count):
                if channel_type == "text":
                    create_tasks.append(guild.create_text_channel(f"{name}-{i+1}-{current_loop}"))
                else:
                    create_tasks.append(guild.create_voice_channel(f"{name}-{i+1}-{current_loop}"))
            
            print(f"{Fore.GREEN}⚡ {self.t('creating')}")
            results = await asyncio.gather(*create_tasks, return_exceptions=True)
            
            created = 0
            for i, result in enumerate(results):
                if not isinstance(result, Exception):
                    created += 1
                    print(f"{Fore.GREEN}⚡ {self.t('created', f'{name}-{i+1}-{current_loop}')}")
            
            print(f"{Fore.GREEN}✅⚡ Utworzono {created}/{count} kanałów TURBO! ⚡")
            
            if not infinite:
                break
                
            # Dodaj opóźnienie między pętlami
            await asyncio.sleep(delay)
        
        input(f"{Fore.WHITE}{self.t('press_enter')}")

    async def role_spammer_turbo(self):
        """Spamer ról TURBO"""
        guild = await self.get_guild()
        if not guild: 
            return
        
        name = input(f"{Fore.WHITE}{self.t('role_name')}").strip() or "SPAM"
        
        # Pobierz ustawienia pętli
        try:
            loop_count = int(input(f"{Fore.WHITE}{self.t('loop_count')}")) or 1
        except:
            loop_count = 1
            
        try:
            delay = float(input(f"{Fore.WHITE}{self.t('delay')}")) or 0.5
        except:
            delay = 0.5
        
        max_limit = 50
        try:
            count = min(int(input(f"{Fore.WHITE}{self.t('count')}{max_limit}): ")) or 30, max_limit)
        except:
            count = 30
        
        current_loop = 0
        infinite = loop_count == 0
        
        while infinite or current_loop < loop_count:
            current_loop += 1
            print(f"{Fore.CYAN}♾️ {self.t('current_loop', current_loop)}")
            
            create_tasks = []
            for i in range(count):
                create_tasks.append(guild.create_role(name=f"{name}-{i+1}-{current_loop}", color=discord.Color.random()))
            
            print(f"{Fore.GREEN}⚡ {self.t('creating')}")
            results = await asyncio.gather(*create_tasks, return_exceptions=True)
            
            created = 0
            for i, result in enumerate(results):
                if not isinstance(result, Exception):
                    created += 1
                    print(f"{Fore.GREEN}⚡ {self.t('created', f'{name}-{i+1}-{current_loop}')}")
            
            print(f"{Fore.GREEN}✅⚡ Utworzono {created}/{count} ról TURBO! ⚡")
            
            if not infinite:
                break
                
            # Dodaj opóźnienie między pętlami
            await asyncio.sleep(delay)
        
        input(f"{Fore.WHITE}{self.t('press_enter')}")

    async def message_spammer_turbo(self):
        """Spamer wiadomości TURBO"""
        guild = await self.get_guild()
        if not guild: 
            return
        
        message_content = input(f"{Fore.WHITE}{self.t('message_content')}").strip()
        if not message_content:
            message_content = "⚡ NUKED BY TURBO NUKER ULTRA ⚡"
        
        # Pobierz ustawienia pętli
        try:
            loop_count = int(input(f"{Fore.WHITE}{self.t('loop_count')}")) or 1
        except:
            loop_count = 1
            
        try:
            delay = float(input(f"{Fore.WHITE}{self.t('delay')}")) or 1.0
        except:
            delay = 1.0
        
        max_limit = 20
        try:
            message_count = min(int(input(f"{Fore.WHITE}{self.t('message_count')}")) or 10, max_limit)
        except:
            message_count = 10
        
        current_loop = 0
        infinite = loop_count == 0
        
        while infinite or current_loop < loop_count:
            current_loop += 1
            print(f"{Fore.CYAN}♾️ {self.t('current_loop', current_loop)}")
            
            text_channels = [channel for channel in guild.channels if isinstance(channel, discord.TextChannel)]
            
            if not text_channels:
                print(f"{Fore.RED}❌ Brak kanałów tekstowych!")
                break
            
            print(f"{Fore.YELLOW}⚡ {self.t('spamming_messages')}")
            
            send_tasks = []
            for channel in text_channels:
                if channel.permissions_for(guild.me).send_messages:
                    for i in range(message_count):
                        # Dodaj losowość do wiadomości, aby uniknąć wykrycia spamu
                        random_msg = f"{message_content} {random.randint(1000, 9999)}"
                        send_tasks.append(channel.send(random_msg))
            
            # Wysyłaj w mniejszych partiach, aby uniknąć rate limitu
            batch_size = 5
            for i in range(0, len(send_tasks), batch_size):
                batch = send_tasks[i:i+batch_size]
                results = await asyncio.gather(*batch, return_exceptions=True)
                
                sent = 0
                for result in results:
                    if not isinstance(result, Exception):
                        sent += 1
                
                print(f"{Fore.GREEN}✅⚡ Wysłano {sent} wiadomości TURBO! ⚡")
                
                # Krótka przerwa między partiami
                await asyncio.sleep(0.5)
            
            if not infinite:
                break
                
            # Dodaj opóźnienie między pętlami
            await asyncio.sleep(delay)
        
        input(f"{Fore.WHITE}{self.t('press_enter')}")

    def run_sync(self):
        """Uruchamia aplikację synchronicznie"""
        print_banner()
        self.get_credentials()
        
        print(f"{Fore.YELLOW}⚡ Uruchamianie bota TURBO...")
        
        try:
            # Poprawione intencje
            intents = discord.Intents.all()
            intents.members = True
            intents.guilds = True
            intents.messages = True
            intents.message_content = True
            
            self.bot = commands.Bot(command_prefix='!', intents=intents)
            
            @self.bot.event
            async def on_ready():
                print(f"{Fore.GREEN}⚡ {self.t('connected', self.bot.user)} ⚡")
                self.bot_ready = True
                await self.main_menu()
            
            self.bot.run(self.token)
            
        except discord.LoginFailure:
            print(f"{Fore.RED}❌ Nieprawidłowy token bota!")
        except Exception as e:
            print(f"{Fore.RED}❌ Błąd: {e}")

# Uruchom aplikację
if __name__ == "__main__":
    try:
        import discord
        import colorama
    except ImportError:
        print(f"{Fore.RED}❌ Zainstaluj wymagane biblioteki:")
        print(f"{Fore.YELLOW}pip install discord.py")
        print(f"{Fore.YELLOW}pip install colorama")
        input("Naciśnij Enter aby wyjść...")
        sys.exit(1)
    
    manager = DiscordManager()
    try:
        manager.run_sync()
    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}❌ Przerwano przez użytkownika")
    except Exception as e:
        print(f"{Fore.RED}❌ Krytyczny błąd: {e}")
    finally:
        input("Naciśnij Enter aby zakończyć...")